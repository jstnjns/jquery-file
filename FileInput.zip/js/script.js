$(function() {
  $('input[type="file"]').fileInput();
});